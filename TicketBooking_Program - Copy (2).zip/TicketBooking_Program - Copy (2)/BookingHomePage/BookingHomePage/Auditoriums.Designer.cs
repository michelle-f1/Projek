﻿namespace BookingHomePage
{
    partial class Auditoriums
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnAddAudit = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnRemoveAudit = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSearchAudit = new System.Windows.Forms.Button();
            this.cbxAuditID = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.npSeats = new System.Windows.Forms.NumericUpDown();
            this.lblLayout = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.npSeats)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(28, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "List of Auditoriums:";
            // 
            // btnAddAudit
            // 
            this.btnAddAudit.Location = new System.Drawing.Point(300, 379);
            this.btnAddAudit.Name = "btnAddAudit";
            this.btnAddAudit.Size = new System.Drawing.Size(129, 27);
            this.btnAddAudit.TabIndex = 1;
            this.btnAddAudit.Text = "Add Auditorium";
            this.btnAddAudit.UseVisualStyleBackColor = true;
            this.btnAddAudit.Click += new System.EventHandler(this.btnAddAudit_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(31, 58);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(398, 189);
            this.dataGridView1.TabIndex = 2;
            // 
            // btnRemoveAudit
            // 
            this.btnRemoveAudit.Location = new System.Drawing.Point(300, 287);
            this.btnRemoveAudit.Name = "btnRemoveAudit";
            this.btnRemoveAudit.Size = new System.Drawing.Size(129, 27);
            this.btnRemoveAudit.TabIndex = 3;
            this.btnRemoveAudit.Text = "Remove Auditorium";
            this.btnRemoveAudit.UseVisualStyleBackColor = true;
            this.btnRemoveAudit.Click += new System.EventHandler(this.btnRemoveAudit_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 268);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Auditorium ID:";
            // 
            // btnSearchAudit
            // 
            this.btnSearchAudit.Location = new System.Drawing.Point(300, 258);
            this.btnSearchAudit.Name = "btnSearchAudit";
            this.btnSearchAudit.Size = new System.Drawing.Size(129, 23);
            this.btnSearchAudit.TabIndex = 6;
            this.btnSearchAudit.Text = "Search";
            this.btnSearchAudit.UseVisualStyleBackColor = true;
            this.btnSearchAudit.Click += new System.EventHandler(this.btnSearchAudit_Click);
            // 
            // cbxAuditID
            // 
            this.cbxAuditID.FormattingEnabled = true;
            this.cbxAuditID.Location = new System.Drawing.Point(152, 260);
            this.cbxAuditID.Name = "cbxAuditID";
            this.cbxAuditID.Size = new System.Drawing.Size(140, 21);
            this.cbxAuditID.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(29, 325);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Add Auditorium:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 350);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(212, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Enter number of seats in Auditorium:";
            // 
            // npSeats
            // 
            this.npSeats.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.npSeats.Location = new System.Drawing.Point(300, 343);
            this.npSeats.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.npSeats.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.npSeats.Name = "npSeats";
            this.npSeats.Size = new System.Drawing.Size(129, 20);
            this.npSeats.TabIndex = 10;
            this.npSeats.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // lblLayout
            // 
            this.lblLayout.AutoSize = true;
            this.lblLayout.Location = new System.Drawing.Point(536, 58);
            this.lblLayout.Name = "lblLayout";
            this.lblLayout.Size = new System.Drawing.Size(213, 13);
            this.lblLayout.TabIndex = 11;
            this.lblLayout.Text = "Visual layout of Auditorium selected:";
            // 
            // Auditoriums
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1284, 701);
            this.Controls.Add(this.lblLayout);
            this.Controls.Add(this.npSeats);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbxAuditID);
            this.Controls.Add(this.btnSearchAudit);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnRemoveAudit);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnAddAudit);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Auditoriums";
            this.Text = "Auditoriums";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Auditoriums_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.npSeats)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAddAudit;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnRemoveAudit;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSearchAudit;
        private System.Windows.Forms.ComboBox cbxAuditID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown npSeats;
        private System.Windows.Forms.Label lblLayout;
    }
}