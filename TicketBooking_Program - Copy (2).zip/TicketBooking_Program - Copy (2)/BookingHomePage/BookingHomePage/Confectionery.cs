﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace BookingHomePage
{
    public partial class Confectionery : Form
    {
        public Confectionery()
        {
            InitializeComponent();
        }
        public string constring = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\theaf\Desktop\TicketBooking_Program\BookingHomePage\BookingHomePage\Cinema.mdf;Integrated Security=True";
        public SqlConnection conn;
        private void btnAddItem_Click(object sender, EventArgs e)
        {
            //Add form maak oop en Item detail word ingesleutel doen validation en lees na databasis
            string insert_item = "INSERT INTO ITEM VALUES(@Item_No,@Item_Name)";
            string sel_max = "SELECT MAX(Item_No) FROM ITEM ";
            conn = new SqlConnection(constring);
            conn.Open();
            SqlCommand insert = new SqlCommand(insert_item, conn);
            SqlCommand max_select = new SqlCommand(sel_max, conn);
            //SqlDataReader read;
            //read = max_select.ExecuteReader();
            int lastItemNo = (int)max_select.ExecuteScalar();
            insert.Parameters.AddWithValue("@Item_No", lastItemNo + 1);
            insert.Parameters.AddWithValue("@Item_Name", txtName.Text);
            
            insert.ExecuteNonQuery();
            conn.Close();


            MessageBox.Show("Item successfully added.");

            try
            {
                conn = new SqlConnection(constring);
                conn.Open();


                SqlDataAdapter adap = new SqlDataAdapter();
                string sql = @"Select * FROM ITEM";
                SqlCommand command = new SqlCommand(sql, conn);
                adap.SelectCommand = command;

                DataSet ds = new DataSet();
                adap.Fill(ds, "Items");

                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Items";

                //populate combobox
                SqlDataReader dataReader;


                dataReader = command.ExecuteReader();
                //Loop through dataset
                while (dataReader.Read())
                {
                    if (!cbxItems.Items.Contains(dataReader.GetValue(1)))
                    {
                        cbxItems.Items.Add(dataReader.GetValue(1));
                    }
                }

                conn.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
            txtName.Text = "";

        }

        private void btnRemoveItem_Click(object sender, EventArgs e)
        {
            try
            {
                //Remove item
                conn = new SqlConnection(constring);
                string del_sql = "DELETE FROM ITEM WHERE Item_Name ='" + cbxItems.SelectedItem + "'";
                conn.Open();
                SqlCommand delete = new SqlCommand(del_sql, conn);
                delete.ExecuteNonQuery();
                conn.Close();
                try
                {
                    conn = new SqlConnection(constring);
                    conn.Open();


                    SqlDataAdapter adap = new SqlDataAdapter();
                    string sql = @"Select * FROM ITEM";
                    SqlCommand command = new SqlCommand(sql, conn);
                    adap.SelectCommand = command;

                    DataSet ds = new DataSet();
                    adap.Fill(ds, "Items");

                    dataGridView1.DataSource = ds;
                    dataGridView1.DataMember = "Items";

                    //populate combobox
                    SqlDataReader dataReader;


                    dataReader = command.ExecuteReader();
                    //Loop through dataset
                    while (dataReader.Read())
                    {
                        if (!cbxItems.Items.Contains(dataReader.GetValue(1)))
                        {
                            cbxItems.Items.Add(dataReader.GetValue(1));
                        }
                    }

                    conn.Close();
                    MessageBox.Show("Item successfully removed.");
                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);
                }
            }
            catch(Exception err)
            {
                MessageBox.Show(err.Message);
            }
            
        }

        private void Confectionery_Load(object sender, EventArgs e)
        {
            try
            {
                conn = new SqlConnection(constring);
                conn.Open();


                SqlDataAdapter adap = new SqlDataAdapter();
                string sql = @"Select * FROM ITEM";
                SqlCommand command = new SqlCommand(sql, conn);
                adap.SelectCommand = command;

                DataSet ds = new DataSet();
                adap.Fill(ds, "Items");

                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Items";

                //populate combobox
                SqlDataReader dataReader;
                

                dataReader = command.ExecuteReader();
                //Loop through dataset
                while (dataReader.Read())
                {
                    if (!cbxItems.Items.Contains(dataReader.GetValue(1)))
                    {
                        cbxItems.Items.Add(dataReader.GetValue(1));
                    }
                }
                

                conn.Close();
            }
            catch(Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void btnSearchItem_Click(object sender, EventArgs e)
        {
            //search for item
            try
            {
                conn = new SqlConnection(constring);
                conn.Open();


                SqlDataAdapter adap = new SqlDataAdapter();
                string sql = @"Select * FROM ITEM WHERE Item_Name ='" + txtSearch.Text + "'";
                SqlCommand search = new SqlCommand(sql, conn);
                adap.SelectCommand = search;

                DataSet ds = new DataSet();
                adap.Fill(ds, "Items");

                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Items";


                conn.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                conn = new SqlConnection(constring);
                conn.Open();


                SqlDataAdapter adap = new SqlDataAdapter();
                string sql = @"Select * FROM SALE";
                SqlCommand command = new SqlCommand(sql, conn);
                adap.SelectCommand = command;

                DataSet ds = new DataSet();
                adap.Fill(ds, "Sales");

                dataGridView2.DataSource = ds;
                dataGridView2.DataMember = "Sales";

                conn.Close();

                

            }
            catch(Exception err)
            {
                MessageBox.Show(err.Message);
            }

            try
            {
                conn = new SqlConnection(constring);
                conn.Open();


                SqlDataAdapter adap2 = new SqlDataAdapter();
                string sql2 = @"Select * FROM SALE_DETAIL";
                SqlCommand command2 = new SqlCommand(sql2, conn);
                adap2.SelectCommand = command2;

                DataSet ds2 = new DataSet();
                adap2.Fill(ds2, "Details");

                dataGridView3.DataSource = ds2;
                dataGridView3.DataMember = "Details";

                conn.Close();
            }
            catch(Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }
    }
}
