﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookingHomePage
{
    public partial class frmNowShowing : Form
    {
        public frmNowShowing()
        {
            InitializeComponent();
        }

        private void frmNowShowing_Load(object sender, EventArgs e)
        {
            /*Set the min date to the current day and the max 7 days from current day,
             because movie schedules are updated every 7 days*/
            dateTimePicker1.MinDate = DateTime.Today;
            dateTimePicker1.MaxDate = DateTime.Today.AddDays(7);
        }

        private void btnToday_Click(object sender, EventArgs e)
        {
            //Display movies on the day
            //if no movies available display message
            DateTime today = DateTime.Today;

        }

        private void btnTomorrow_Click(object sender, EventArgs e)
        {
            //Display movies for the following day
            //if no movies available display message
            DateTime tomorrow = DateTime.Today.AddDays(1);
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            //Display movies for the selected date
            //if no movies available display message 
            string selectedDate = dateTimePicker1.Value.ToString("yyyy-mm-dd");
            // opsie #2 string theDate = dateTimePicker1.Value.ToShortDateString();
        }
    }
}
