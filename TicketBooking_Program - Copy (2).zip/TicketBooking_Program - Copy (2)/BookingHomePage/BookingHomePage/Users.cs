﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace BookingHomePage
{
    public partial class Users : Form
    {
        public Users()
        {
            InitializeComponent();
        }
        public string constring = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\theaf\Desktop\TicketBooking_Program\BookingHomePage\BookingHomePage\Cinema.mdf;Integrated Security=True";
        public SqlConnection conn;
        private void btnAdd_Click(object sender, EventArgs e)
        {
            Boolean valid = true; // boolean value to setermine whether information may be added into database

            errorProvider1.SetError(txtPassword,"");
            if( txtPassword.Text == null || txtConfirmPass.Text == null)
            {
                errorProvider1.SetError(txtPassword,"Please enter Password!");
                txtConfirmPass.Text = "";
                txtPassword.Text = "";
                valid = false;
            }
            else
            {
                errorProvider1.Clear();
                
            }

            errorProvider2.SetError(txtConfirmPass,"");
            if (txtPassword.Text != txtConfirmPass.Text)
            {
                errorProvider2.SetError(txtConfirmPass, "Passwords do not match!");
                txtConfirmPass.Text = "";
                txtPassword.Text = "";
                valid = false;
            }
            else
            {
                errorProvider2.Clear();

            }
            //Insert an employee
            if(valid == true)
            {
                string insert_user = "INSERT INTO EMPLOYEE VALUES(@Employee_No,@Employee_Name,@Employee_Surname," +
                    "@Employee_Username,@Employee_Password,@Manager)";
                string sel_max = "SELECT MAX(Employee_No) FROM EMPLOYEE ";
                conn = new SqlConnection(constring);
                conn.Open();
                SqlCommand insert = new SqlCommand(insert_user,conn);
                SqlCommand max_select = new SqlCommand(sel_max, conn);
                //SqlDataReader read;
                //read = max_select.ExecuteReader();
                int lastEmpNo = (int)max_select.ExecuteScalar();
                insert.Parameters.AddWithValue("@Employee_No",lastEmpNo+1);
                insert.Parameters.AddWithValue("@Employee_Name", txtName.Text);
                insert.Parameters.AddWithValue("@Employee_Surname", txtSurname.Text);
                insert.Parameters.AddWithValue("@Employee_Username", txtUsername.Text);
                insert.Parameters.AddWithValue("@Employee_Password", txtPassword.Text);
                if(chkManager.Checked)
                {
                    insert.Parameters.AddWithValue("@Manager", 1);
                }
                else
                {
                    insert.Parameters.AddWithValue("@Manager", 0);
                }
                
                insert.ExecuteNonQuery();
                conn.Close();
            }

            //fill datagridview
            conn = new SqlConnection(constring);
            conn.Open();


            SqlDataAdapter adap = new SqlDataAdapter();
            string sql = @"Select * FROM EMPLOYEE";
            SqlCommand command = new SqlCommand(sql, conn);
            adap.SelectCommand = command;

            DataSet ds = new DataSet();
            adap.Fill(ds, "Users");

            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Users";

            //populate combobox
            SqlDataReader dataReader;
            string output = "";

            dataReader = command.ExecuteReader();
            //Loop through dataset
            while (dataReader.Read())
            {
                if (!cbxUsers.Items.Contains(dataReader.GetValue(3)))
                {
                    cbxUsers.Items.Add(dataReader.GetValue(3));
                }
            }
            conn.Close();
        }

        private void Users_Load(object sender, EventArgs e)
        {
            //fill datagridview
            conn = new SqlConnection(constring);
            conn.Open();
            
       
            SqlDataAdapter adap = new SqlDataAdapter();
            string sql = @"Select * FROM EMPLOYEE";
            SqlCommand command = new SqlCommand(sql,conn);
            adap.SelectCommand = command;

            DataSet ds = new DataSet();
            adap.Fill(ds,"Users");

            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Users";

            //populate combobox
            SqlDataReader dataReader;
            string output = "";

            dataReader = command.ExecuteReader();
            //Loop through dataset
            while(dataReader.Read())
            {
                if(!cbxUsers.Items.Contains(dataReader.GetValue(3)))
                {
                    cbxUsers.Items.Add(dataReader.GetValue(3));
                }
            }
            conn.Close();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            //Confirm removal
            DialogResult result;
            result = MessageBox.Show("Are you sure you want to remove this user/employee?", "Remove Employee", MessageBoxButtons.YesNo);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                //remove user
                try
                {
                    string delete_user = "DELETE FROM EMPLOYEE WHERE Employee_Username = '" + cbxUsers.SelectedItem.ToString() + "'";
                    conn = new SqlConnection(constring);
                    conn.Open();
                    SqlCommand command = new SqlCommand(delete_user, conn);
                    command.ExecuteNonQuery();
                    conn.Close();

                    //fill datagridview
                    conn = new SqlConnection(constring);
                    conn.Open();


                    SqlDataAdapter adap = new SqlDataAdapter();
                    string sql = @"Select * FROM EMPLOYEE";
                    SqlCommand sel_command = new SqlCommand(sql, conn);
                    adap.SelectCommand = sel_command;

                    DataSet ds = new DataSet();
                    adap.Fill(ds, "Users");

                    dataGridView1.DataSource = ds;
                    dataGridView1.DataMember = "Users";

                    //populate combobox
                    SqlDataReader dataReader;
                    string output = "";

                    dataReader = sel_command.ExecuteReader();
                    //Loop through dataset
                    while (dataReader.Read())
                    {
                        if (!cbxUsers.Items.Contains(dataReader.GetValue(3)))
                        {
                            cbxUsers.Items.Add(dataReader.GetValue(3));
                        }
                    }
                    conn.Close();
                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);
                }
            }
            else
            {
                MessageBox.Show("Removal was cancelled.");

            }

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //search for user
            try
            {
                conn = new SqlConnection(constring);
                conn.Open();


                SqlDataAdapter adap = new SqlDataAdapter();
                string sql = @"Select * FROM EMPLOYEE WHERE Employee_Username ='" + txtSearch.Text + "'";
                SqlCommand search = new SqlCommand(sql, conn);
                adap.SelectCommand = search;

                DataSet ds = new DataSet();
                adap.Fill(ds, "Users");

                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Users";


                conn.Close();
            }
            catch(Exception err)
            {
                MessageBox.Show(err.Message);
            }

        }
    }
}
