﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookingHomePage
{
    public partial class Bookings : Form
    {
        public Bookings()
        {
            InitializeComponent();
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {



        }

        private void tabControl1_Selected(object sender, TabControlEventArgs e)
        {

        }
        

        private void Bookings_Load(object sender, EventArgs e)
        {
            
            
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            //Maak Cancel Booking form oop en remove die booking kanselleer bespreekte sitplekke
            CancelBooking frmCancel = new CancelBooking();
            frmCancel.Show();
            int bookingID = Convert.ToInt32(frmCancel.txtBookingID.Text);
            //remove booking and reserved seats
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            Seats frmSeats = new Seats();
            frmSeats.Show();

        }
    }
}
