﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace BookingHomePage
{
    public partial class Auditoriums : Form
    {
        public Auditoriums()
        {
            InitializeComponent();
        }
        public string constring = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\theaf\Desktop\TicketBooking_Program\BookingHomePage\BookingHomePage\Cinema.mdf;Integrated Security=True";
        public SqlConnection conn;
        private void btnAddAudit_Click(object sender, EventArgs e)
        {
            string insert_au = "INSERT INTO AUDITORIUM VALUES(@Auditorium_id,@Number_of_Seats)";
            string sel_max = "SELECT MAX(Auditorium_id) FROM AUDITORIUM ";
            conn = new SqlConnection(constring);
            conn.Open();
            SqlCommand insert = new SqlCommand(insert_au, conn);
            SqlCommand max_select = new SqlCommand(sel_max, conn);
            //SqlDataReader read;
            //read = max_select.ExecuteReader();
            int lastItemNo = (int)max_select.ExecuteScalar();
            insert.Parameters.AddWithValue("@Auditorium_id", lastItemNo + 1);
            insert.Parameters.AddWithValue("@Number_of_Seats", npSeats.Value);

            insert.ExecuteNonQuery();
            conn.Close();


            MessageBox.Show("Auditorium successfully added.");

            try
            {
                conn = new SqlConnection(constring);
                conn.Open();


                SqlDataAdapter adap = new SqlDataAdapter();
                string sql = @"Select * FROM AUDITORIUM";
                SqlCommand command = new SqlCommand(sql, conn);
                adap.SelectCommand = command;

                DataSet ds = new DataSet();
                adap.Fill(ds, "Audits");

                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Audits";

                //populate combobox
                SqlDataReader dataReader;


                dataReader = command.ExecuteReader();
                //Loop through dataset
                while (dataReader.Read())
                {
                    if (!cbxAuditID.Items.Contains(dataReader.GetValue(0)))
                    {
                        cbxAuditID.Items.Add(dataReader.GetValue(0));
                    }
                }

                conn.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void btnRemoveAudit_Click(object sender, EventArgs e)
        {
            //Remove
            try
            {
                //Remove item
                conn = new SqlConnection(constring);
                string del_sql = "DELETE FROM AUDITORIUM WHERE Auditorium_id ='" + cbxAuditID.SelectedItem + "'";
                conn.Open();
                SqlCommand delete = new SqlCommand(del_sql, conn);
                delete.ExecuteNonQuery();
                conn.Close();
                try
                {
                    conn = new SqlConnection(constring);
                    conn.Open();


                    SqlDataAdapter adap = new SqlDataAdapter();
                    string sql = @"Select * FROM AUDITORIUM";
                    SqlCommand command = new SqlCommand(sql, conn);
                    adap.SelectCommand = command;

                    DataSet ds = new DataSet();
                    adap.Fill(ds, "Audits");

                    dataGridView1.DataSource = ds;
                    dataGridView1.DataMember = "Audits";

                    //populate combobox
                    SqlDataReader dataReader;


                    dataReader = command.ExecuteReader();
                    //Loop through dataset
                    while (dataReader.Read())
                    {
                        if (!cbxAuditID.Items.Contains(dataReader.GetValue(1)))
                        {
                            cbxAuditID.Items.Add(dataReader.GetValue(1));
                        }
                    }

                    conn.Close();
                    MessageBox.Show("Auditorium successfully removed.");
                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void Auditoriums_Load(object sender, EventArgs e)
        {
            lblLayout.Visible = false;

            try
            {
                conn = new SqlConnection(constring);
                conn.Open();


                SqlDataAdapter adap = new SqlDataAdapter();
                string sql = @"Select * FROM AUDITORIUM";
                SqlCommand command2 = new SqlCommand(sql, conn);
                adap.SelectCommand = command2;

                DataSet ds = new DataSet();
                adap.Fill(ds, "Audit");

                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Audit";

                conn.Close();

                conn = new SqlConnection(constring);
                conn.Open();


                SqlDataAdapter adapR = new SqlDataAdapter();
                string sqlR = @"Select * FROM AUDITORIUM";
                SqlCommand command = new SqlCommand(sqlR, conn);
                adapR.SelectCommand = command;

                DataSet dsR = new DataSet();
                adapR.Fill(dsR, "A");

                dataGridView1.DataSource = dsR;
                dataGridView1.DataMember = "A";

                //populate combobox
                SqlDataReader dataReader;


                dataReader = command.ExecuteReader();
                //Loop through dataset
                while (dataReader.Read())
                {
                    if (!cbxAuditID.Items.Contains(dataReader.GetValue(0)))
                    {
                        cbxAuditID.Items.Add(dataReader.GetValue(0));
                    }
                }

                conn.Close();
            }
            catch(Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void btnSearchAudit_Click(object sender, EventArgs e)
        {
            lblLayout.Visible = true;
            int noSeats, row = 0;

            //search 
            try
            {
                conn = new SqlConnection(constring);
                conn.Open();


                SqlDataAdapter adap = new SqlDataAdapter();
                string sql = @"Select * FROM AUDITORIUM WHERE  Auditorium_id='" + cbxAuditID.SelectedItem + "'";
                SqlCommand search = new SqlCommand(sql, conn);
                adap.SelectCommand = search;

                DataSet ds = new DataSet();
                adap.Fill(ds, "Audit");

                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Audit";


                conn.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }

            try
            {
                conn = new SqlConnection(constring);
                conn.Open();


                SqlDataAdapter adapR = new SqlDataAdapter();
                string sqlR = @"Select * FROM AUDITORIUM WHERE Auditorium_id = '"+ cbxAuditID.SelectedItem+"'";
                SqlCommand command = new SqlCommand(sqlR, conn);
                adapR.SelectCommand = command;

                DataSet dsR = new DataSet();
                adapR.Fill(dsR, "A");

                dataGridView1.DataSource = dsR;
                dataGridView1.DataMember = "A";

                //populate combobox
                SqlDataReader dataReader;

                int seats;
                dataReader = command.ExecuteReader();
                //Loop through dataset
                while (dataReader.Read())
                {
                    seats = (int)dataReader.GetValue(1);
                    row = seats / 10;
                }

                conn.Close();
            }
            catch(Exception err)
            {
                MessageBox.Show(err.Message);
            }
            //lees gereserveerde sitplekke vir huidige dag en dui aan dit is gereserveer

            noSeats = 0; //tel sitplekke vir elke booking
            int top = 95;
            int left = 510;
            int count = 0;
            int buttonH = 0;
            
            for (int i = 0; i < 10; i++) //10 rye
            {
                for (int j = 0; j < row; j++) //15 sitplekke
                {
                    count++;
                    Button button = new Button();
                    button.Name = "btn" + count.ToString();
                    button.Left = left;
                    button.Top = top;
                    this.Controls.Add(button);
                    button.BackgroundImage = Image.FromFile(@"C:\Users\theaf\Desktop\TicketBooking_Program\seat.jpg");
                    button.BackgroundImage.Height.Equals(button.Height);
                    button.Height = button.Height + 10;
                    button.Width = button.Height;
                    button.BackgroundImage.Width.Equals(button.Width);
                    button.BackgroundImageLayout = ImageLayout.Stretch;
                    left += button.Width + 2;
                    buttonH = button.Height;

                }
                
                    top += buttonH + 2;
                    left = 510;
                
            }
            

        }
    }
}
