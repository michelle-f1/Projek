﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookingHomePage
{
    public partial class Seats : Form
    {
        public Seats()
        {
            InitializeComponent();
        }
        public int noSeats;
        public void button_Click(object sender, EventArgs e)
        {
            Button currentButton = (Button)sender;
            currentButton.BackgroundImage = Image.FromFile(@"C:\Users\theaf\Desktop\TicketBooking_Program\reserved.jpg");
            currentButton.BackgroundImageLayout = ImageLayout.Stretch;
            noSeats++; //Aantal sitplekke per booking, moet in databasis ingelees word
        }
        private void Seats_Load(object sender, EventArgs e)
        {
            //lees gereserveerde sitplekke vir huidige dag en dui aan dit is gereserveer

            noSeats = 0; //tel sitplekke vir elke booking
            int top = 40;
            int left = 20;
            int count = 0;
            int buttonH = 0;
            for (int i = 0; i < 10; i++) //10 rye
            {
                for (int j = 0; j < 15; j++) //15 sitplekke
                {
                    count++;
                    Button button = new Button();
                    button.Name = "btn" + count.ToString();
                    button.Left = left;
                    button.Top = top;
                    this.Controls.Add(button);
                    button.BackgroundImage = Image.FromFile(@"C:\Users\theaf\Desktop\TicketBooking_Program\seat.jpg");
                    button.BackgroundImage.Height.Equals(button.Height);
                    button.Height = button.Height + 10;
                    button.Width = button.Height;
                    button.BackgroundImage.Width.Equals(button.Width);
                    button.BackgroundImageLayout = ImageLayout.Stretch;
                    button.Click += new EventHandler(this.button_Click);
                    left += button.Width + 2;
                    buttonH = button.Height;

                }
                top += buttonH + 2;
                left = 20;
            }
            }
    }
}
