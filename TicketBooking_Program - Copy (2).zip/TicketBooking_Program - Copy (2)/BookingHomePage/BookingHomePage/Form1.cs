﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookingHomePage
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        //public string openFrom = "";
        private void dashboardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Close all open forms except Form1
            for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
            {
                if (Application.OpenForms[i].Name != "Form1")
                    Application.OpenForms[i].Close();
            }

            //Open Dashboard form
            Dashboard frmDash = new Dashboard();
            frmDash.MdiParent = this;
            frmDash.Show();
           
        }

        private void Form1_MdiChildActivate(object sender, EventArgs e)
        {

        }

        private void nowShowingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Close all open forms except Form1
            for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
            {
                if (Application.OpenForms[i].Name != "Form1")
                    Application.OpenForms[i].Close();
            }

            //Open NowShowing form
            frmNowShowing frmShow = new frmNowShowing();
            frmShow.MdiParent = this;
            frmShow.Show();
        }

        private void bookingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Close all open forms except Form1
            for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
            {
                if (Application.OpenForms[i].Name != "Form1")
                    Application.OpenForms[i].Close();
            }

            //Open Bookings form
            Bookings frmBook = new Bookings();
            frmBook.MdiParent = this;
            frmBook.Show();
        }

        private void moviesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Close all open forms except Form1
            for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
            {
                if (Application.OpenForms[i].Name != "Form1")
                    Application.OpenForms[i].Close();
            }

            //Open Movies form
            Movies frmMovie = new Movies();
            frmMovie.MdiParent = this;
            frmMovie.Show();
        }

        private void auditoriumsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Close all open forms except Form1
            for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
            {
                if (Application.OpenForms[i].Name != "Form1")
                    Application.OpenForms[i].Close();
            }

            //Open Auditoriums form
            Auditoriums frmAudit = new Auditoriums();
            frmAudit.MdiParent = this;
            frmAudit.Show();
        }

        private void confetioneryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Close all open forms except Form1
            for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
            {
                if (Application.OpenForms[i].Name != "Form1")
                    Application.OpenForms[i].Close();
            }

            //Open Confectionery form
            Confectionery frmConfec = new Confectionery();
            frmConfec.MdiParent = this;
            frmConfec.Show();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result;
            result = MessageBox.Show("Are you sure you want to logout?","Logout confirmation",MessageBoxButtons.YesNo);
            if(result == System.Windows.Forms.DialogResult.Yes)
            {
                Application.Exit(); // close eprogram
            }
            else
            {
                //Close all open forms except Form1
                for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
                {
                    if (Application.OpenForms[i].Name != "Form1")
                        Application.OpenForms[i].Close();
                }

                //Open Dashboard form
                Dashboard frmDash = new Dashboard();
                frmDash.MdiParent = this;
                frmDash.Show();
            }
        }

        private void employeesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Close all open forms except Form1
            for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
            {
                if (Application.OpenForms[i].Name != "Form1")
                    Application.OpenForms[i].Close();
            }

            //Open Users form
            Users frmUsers = new Users();
            frmUsers.MdiParent = this;
            frmUsers.Show();
        }

        private void reportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Close all open forms except Form1
            for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
            {
                if (Application.OpenForms[i].Name != "Form1")
                    Application.OpenForms[i].Close();
            }

            //Open Reports form
            Reports frmReports = new Reports();
            frmReports.MdiParent = this;
            frmReports.Show();
        }
    }
    }


